package test.Assignment.Tests;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import test.Assignment.BaseLibrary.BaseClass;
import test.Assignment.PageObject.BookingPage;

public class BookingPageTest extends BaseClass {
	
	String url = "https://www.booking.com/flights/index.en-gb.html.";
	
	@Test (enabled=true, priority = 1)
	public void Booking() throws InterruptedException, IOException
	{
		
	BookingPage bp = new BookingPage(driver);
		bp.navigate(url);
		//System.out.println(bp.selectOriginFrom("DEL"));
		Assert.assertTrue(bp.selectOriginFrom("DEL"));
		bp.selectOriginTo("BOM");
		bp.selectDate();
	}
	@Test(enabled = true,priority = 2)
	public void addPassengers()
	{
		BookingPage bp = new BookingPage(driver);
		bp.addPassenger(3);
		
	}
	@Test(enabled = true,priority = 3)
	public void searchFlight()
	{
		BookingPage bp = new BookingPage(driver);
		bp.searchFlight();
	}
	
	
}
