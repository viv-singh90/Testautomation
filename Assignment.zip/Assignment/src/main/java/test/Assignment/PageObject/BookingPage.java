package test.Assignment.PageObject;

import java.util.ArrayList;
import java.util.List;

import org.jspecify.annotations.Nullable;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByCssSelector;
import org.openqa.selenium.By.ByTagName;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;
import net.bytebuddy.asm.Advice.Return;
import test.Assignment.BaseLibrary.BaseClass;

public class BookingPage {
	
	private WebDriver driver;
	
	public BookingPage(WebDriver driver)
	{
		this.driver = driver;
		 PageFactory.initElements(driver, this); 
	}
	
	@FindBy(id="search_type_option_ROUNDTRIP")
	WebElement rb_roundTrip;
	
	@FindBy(className="Tags-module__text___90E7G")
	WebElement txt_origin_from;
	
	
	@FindBy(xpath="//button[@data-ui-name='input_location_from_segment_0']")
	WebElement btn_origin_From;
	
	
	@FindBy(className="AutoComplete-module__textInput___Qh3I-")
	WebElement txt_To;
	
	
	@FindBy(xpath="//button[@data-ui-name='input_location_to_segment_0']")
	WebElement btn_To;
	
	@FindBy(className="List-module__content___48Y6B")
	WebElement value_To;
	
	
	  @FindBy(xpath="//ul[@id='flights-searchbox_suggestions']/li/span[2]/span/b")
	  
	  List<WebElement> list_OriginTo;
	 

	  @FindBy (xpath="//span[contains(text(),'Done')]")
	  WebElement btn_Done;
	  
	  
	  @FindBy (css="button[data-ui-name='button_occupancy']")
	  WebElement btn_occupancy;
	  
	  @FindBy (css=" button[data-ui-name='button_occupancy_adults_plus']")
	  WebElement btn_Adult_Plus;
	
	  
	  @FindBy (css="button[data-ui-name='button_occupancy_action_bar_done']")
	  WebElement btn_occupancy_done;
	  
	  @FindBy(css="button[data-ui-name='button_search_submit']")
	  WebElement btn_search_submit;
	   
	public void navigate(String URL) {
		
		driver.get(URL);
	}
	
		
	public boolean chkRoundTrip()
	{
		if(rb_roundTrip.isSelected())
		{
			return true;
		}
		else
		{
			rb_roundTrip.click();
			return true;
		}
	}
	
	public boolean selectOriginFrom(String From)
	{
		String txtFrom = "";
		if(chkRoundTrip())
		{
			btn_origin_From.click();
			txtFrom = txt_origin_from.getText();
			
		}
		String[] originFrom = txtFrom.split(" ");
		if (originFrom[0].contentEquals(From))
		{
			btn_To.click();
			return true;
		}
		return false;
		
	}
	public Boolean selectOriginTo(String To) throws InterruptedException
	{
		txt_To.sendKeys(To);
		Thread.sleep(3000L);
		value_To.click();
		 return true;
		
	
}
	
	@FindBy (xpath="//button[@data-ui-name='button_date_segment_0']")
	
	WebElement datePicker;
	
	@FindBy (css="td[role='gridcell']")
	
	List <WebElement> Dates;
	
	ArrayList <String> selectedDate;
	public void selectDate() throws InterruptedException
	{
		
		datePicker.click();
		for(WebElement element:Dates)
		{
			WebElement ele = element.findElement(By.cssSelector("span"));
			String value = ele.getAttribute("aria-checked");
			
			//System.out.println(value);
			if (value.equalsIgnoreCase("true"))
			{
				
				selectedDate = new ArrayList<String>();
				String date = ele.getAttribute("aria-label");
				selectedDate.add(date);
				System.out.println(selectedDate);
			
		}
			else
			{
				String datefromselect = ele.getAttribute("data-date");
				if(datefromselect.equalsIgnoreCase("2024-11-11") || datefromselect.equalsIgnoreCase("2024-11-16"))
				{
					ele.click();
				//	btn_Done.click();
				}
			}
				
	}
		Thread.sleep(3000L);
		btn_Done.click();
		//System.out.println(selectedDate.size());
	
}
	
	public void addAdult(int num)
	{
		while(num>=1)
		{
			btn_Adult_Plus.click();
			num--;
		}
	}
	
public void addPassenger(int adult)
{
	btn_occupancy.click();
	addAdult(adult);
	btn_occupancy_done.click();
}
public void searchFlight()
{
	btn_search_submit.click();
}

}
