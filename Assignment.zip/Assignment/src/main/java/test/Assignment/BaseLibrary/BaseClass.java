package test.Assignment.BaseLibrary;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class BaseClass {

	protected WebDriver driver;
	
	@BeforeTest
	public void setupDriver()
	{
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
	}
	@AfterTest
	public void tearDown()
	{
		
	}
	
	public String getPropertiesValue(String key) throws IOException
	{
		FileInputStream propertyFile = null;
		try {
			propertyFile = new FileInputStream("/Assignment/src/main/java/test/Assignment/Utility/Properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Properties prop  = new Properties();
		prop.load(propertyFile);
		return prop.getProperty(key);
	}
	
	
}
